<?php

$servername = "localhost";
$username = "id15342548_moodledb";
$password = "k/=)%&Y2TVnl?WKm";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
	die("");
  die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";
?>
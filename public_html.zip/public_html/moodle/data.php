<?php
require_once('db.php');
header('Access-Control-Allow-Origin: *');
$db = "moodle";
$db = "id15342548_moodle";
$null_id = 55555;

if(isset($_REQUEST['return']) && !empty($_REQUEST['return'])){
	echo $conn -> real_escape_string($_REQUEST['return']);
}

if(isset($_REQUEST['data']) && !empty($_REQUEST['data'])){

	$questions = json_decode(urldecode($_REQUEST['data']), true);
	print_r($questions);
	foreach($questions as $question){
		
		$name = $conn -> real_escape_string($question['name']);
		$qtext = $conn -> real_escape_string($question['text']);
		$qtype = $conn -> real_escape_string($question['type']);
		$anstext = $conn -> real_escape_string($question['youranswer']);
		
		if(!empty($qtype)){
			setName($name);
			setQuestion($qtype, $qtext, $name);
			
			foreach($question['options'] as $option){
				setOption($qtext, $option);
			}
			setAnswer($qtext, $anstext, $name);
		}
	}
}
if(isset($_REQUEST['getAnswer']) && !empty($_REQUEST['getAnswer'])){
	$questions = json_decode(urldecode($_REQUEST['getAnswer']), true);
	getAnswer($conn -> real_escape_string($questions['qtext']), $questions['qtype'] );
}



function getAnswer($qtext, $qtype){
	
	global $conn, $null_id, $db;
	//http://localhost/data.php?getAnswer=1&questionText=what%20is%20your%20name&questionType=multichoice
	
	$sql = "SELECT text from $db.options WHERE id = (SELECT a.optionId FROM (SELECT count(a.optionId) as counter, a.optionId FROM $db.question q inner join $db.question_text qt on q.textId = qt.id inner join $db.answer a on a.questionId=q.id
                where q.type='$qtype' and qt.text='$qtext' group by a.optionId) a ORDER by counter DESC LIMIT 1)";
	
	$sql = "SELECT a.optionId, a.counter FROM (SELECT count(a.optionId) as counter, a.optionId FROM $db.question q inner join $db.question_text qt on q.textId = qt.id inner join $db.answer a on a.questionId=q.id
           where q.type='$qtype' and qt.text='$qtext' group by a.optionId) a ORDER by counter DESC limit 1";
	
	if ($result = $conn->query($sql)) {
	  	if ($result->num_rows > 0) {

			$array = [];
			$row = $result->fetch_assoc();
			$id = $row['optionId'];
			$sql2 = "SELECT text from $db.options WHERE id = '$id'";
			$result2 = $conn->query($sql2);
			//echo '{"text":"'.$qtext.'","answer":"'.$result2->fetch_assoc()['text'].'"}';
			//if($row['counter'] >= num_options($qtext) * 0.50){
				echo $result2->fetch_assoc()['text'];
			//}
			
		}
	} else {
	  echo "Error: " . $sql . "<br>" . $conn->error;
	}

}

function num_active_users(){
	global $conn, $db;
	$sql = "SELECT count(*) as active_users FROM $db.active_user_question WHERE timestampdiff(second, last_active, CURRENT_TIMESTAMP) < 60";
	if ($result = $conn->query($sql)) {
		$result->fetch_assoc()['active_users'];
	} else {
	  echo "Error: " . $sql . "<br>" . $conn->error;
	}
	//$sql = "SELECT questionId, timestampdiff(second, last_active, CURRENT_TIMESTAMP) as last_active FROM `active_user_question` where userId = (SELECT id from $db.users where name='Dalveer Singh');";
}

function num_answers($qtext){
	global $conn, $db;
	$sql = "SELECT count(*) as counter FROM $db.answer where questionId=(SELECT id from $db.question where textId=(SELECT id from $db.question_text where text='$qtext'))";
	if ($result = $conn->query($sql)) {
		return $result->fetch_assoc()['counter'];
	} else {
	  echo "Error: " . $sql . "<br>" . $conn->error;
	}
}
function num_options($qtext){
	global $conn, $db;
	$sql = "SELECT count(*) as options FROM $db.options where questionId=(SELECT id from $db.question where textId=(SELECT id from $db.question_text where text='$qtext'))";
	if ($result = $conn->query($sql)) {
		return $result->fetch_assoc()['options'];
	} else {
	  echo "Error: " . $sql . "<br>" . $conn->error;
	}
}


function setName($name){
	global $conn, $null_id, $db;
	$student_id = '';
	$sql = "INSERT INTO $db.users (name, student_id)
		VALUES ('$name', '$student_id')";
		
	if ($conn->query($sql) === TRUE) {
	  	$sql = "INSERT INTO $db.active_user_question (userId, questionId) values ((SELECT id from $db.users where name='$name' limit 1), '$null_id')";
		if ($conn->query($sql) === TRUE) {
			
		} else {
		  //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	} else {
	  //echo "Error: " . $sql . "<br>" . $conn->error;
	}

}

function setQuestion($questionType, $questionText, $name){
	global $conn, $null_id, $db;
	$sql = "INSERT INTO $db.question_text (text)
		VALUES ('$questionText')";
	$conn->query($sql);

	$sql = "INSERT INTO $db.question (type, textId)
	VALUES ('$questionType', (SELECT id from $db.question_text where text='$questionText' limit 1))";
	
	if ($conn->query($sql) === TRUE) {
	  //echo "New record created successfully";
	} else {
	  //echo "Error: " . $sql . "<br>" . $conn->error;
	}
	
	$sql = "UPDATE $db.active_user_question set last_active=CURRENT_TIMESTAMP, questionId=(SELECT id from $db.question where textId=(SELECT id from $db.question_text where text='$questionText' limit 1)) where userId = (SELECT id from $db.users where name='$name' limit 1)";
	if ($conn->query($sql) === TRUE) {
	  	
	} else {
	  echo "Error: " . $sql . "<br>" . $conn->error;
	}
}

function setOption($questionText, $optionText){
	global $conn, $null_id, $db;
	$sql = "INSERT INTO $db.options (questionId, text)
	VALUES ((SELECT id FROM $db.question where textId=(SELECT id from $db.question_text where text='$questionText' limit 1)), '$optionText')";
		
	if ($conn->query($sql) === TRUE) {
	  //echo "New record created successfully";
	} else {
	  //echo "Error: " . $sql . "<br>" . $conn->error;
	}
	
}

function setAnswer($questionText, $answerText, $name){
	global $conn, $null_id, $db;
	if(empty($answerText)){
		return;
	}
	$sql = "INSERT INTO $db.answer (userId, questionId, optionId) Select (SELECT id from $db.users where name='$name' limit 1) as userId, q.id as questionId, o.id as optionId from 
		$db.question q inner join $db.question_text qt on q.textId=qt.id
		inner join $db.options o on o.questionId = q.id where o.text='$answerText' and qt.text = '$questionText'";
			
	if ($conn->query($sql) === TRUE) {
	  //echo "New record created successfully";
	}else {
	  //echo "Error: " . $sql . "<br>" . $conn->error;
	  
	  	$sql = "UPDATE $db.answer set optionId = 
		(SELECT o.id from $db.question_text qt inner join $db.question q on q.textId=qt.id inner join $db.options o on o.questionId=q.id where o.text = '$answerText' and qt.text = '$questionText')
		where userId=(SELECT id from $db.users where name='$name' limit 1) and questionId=(SELECT id from $db.question where textId=(select id from $db.question_text where text='$questionText'))";
		if($conn->query($sql) === TRUE){
			//echo "Answer updated<br>";
			//echo $name.'<br>';
			//echo $questionText.'<br>';
			//echo $answerText;
		}else{
			//echo "Error: " . $sql . "<br>" . $conn->error;
		}
	}
}


// ----------- End -----------
$conn->close();

?>